const products=[
{name:"Chairs",price:20},{name:"Tables",price:100},{name:"Decoration Set",price:500},
{name:"Stage Set",price:2000},{name:"Sound System",price:1500},{name:"Lighting Set",price:1000},
{name:"Tent / Canopy",price:2500},{name:"Catering Equipment",price:1200}];
const material=document.getElementById("material");
products.forEach((p,i)=>{let o=document.createElement("option");o.value=i;o.textContent=`${p.name} - ₹${p.price}`;material.appendChild(o);});
const saved=JSON.parse(localStorage.getItem("selectedMaterial")||"null");
if(saved){let i=products.findIndex(p=>p.name===saved.name);if(i>=0)material.value=i;}
function total(){const p=products[material.value];const q=Number(document.getElementById("quantity").value)||0;document.getElementById("total").textContent=`Total: ₹${p.price*q}`;}
material.addEventListener("change",total);document.getElementById("quantity").addEventListener("input",total);total();
document.getElementById("orderForm").addEventListener("submit",e=>{
e.preventDefault();const date=document.getElementById("date").value;
if(new Date(date)<new Date(new Date().toDateString())){alert("Please choose a future event date.");return;}
document.getElementById("message").innerHTML='<p class="contact-info">✅ Order request submitted successfully! Our team will contact you.</p>';
e.target.reset();total();
});
