const products=[
{name:"Chairs",price:20,icon:"🪑",desc:"Comfortable function chairs."},
{name:"Tables",price:100,icon:"🪵",desc:"Tables for dining and event arrangements."},
{name:"Decoration Set",price:500,icon:"🎈",desc:"Balloons and decorative accessories."},
{name:"Stage Set",price:2000,icon:"🎭",desc:"Stage and backdrop materials."},
{name:"Sound System",price:1500,icon:"🔊",desc:"Speakers and microphones."},
{name:"Lighting Set",price:1000,icon:"💡",desc:"LED and decorative event lights."},
{name:"Tent / Canopy",price:2500,icon:"⛺",desc:"Outdoor event covering."},
{name:"Catering Equipment",price:1200,icon:"🍽️",desc:"Basic serving and catering equipment."}
];
const list=document.getElementById("product-list");
list.innerHTML=products.map((p,i)=>`<article class="product-card"><div class="icon">${p.icon}</div><h3>${p.name}</h3><p>${p.desc}</p><div class="price">₹${p.price} / unit</div><button class="btn" onclick="choose(${i})">Order</button></article>`).join("");
function choose(i){localStorage.setItem("selectedMaterial",JSON.stringify(products[i]));location.href="order.html";}
