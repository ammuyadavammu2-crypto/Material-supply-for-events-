# EventPro - Event Material Supply

A responsive front-end project for an event material supply business.

## Features
- Home page
- Event material catalogue
- Dynamic product cards
- Order form
- Automatic total-price calculation
- Customer validation
- Contact page
- About page
- Responsive mobile design
- LocalStorage selection between product and order pages

## Files
- index.html
- products.html
- order.html
- about.html
- contact.html
- css/style.css
- js/products.js
- js/order.js
- js/script.js

## How to run
Open `index.html` in a browser.

## GitHub
Upload the complete `event-material-supply` folder to a GitHub repository. No server is required for this demo.
